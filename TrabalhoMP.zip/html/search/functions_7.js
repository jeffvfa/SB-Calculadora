var searchData=
[
  ['testabrirarquivo',['testAbrirArquivo',['../teste__calculadora_8c.html#a340ca12627a4d506dae3c1a56799b25d',1,'teste_calculadora.c']]],
  ['testarexpr',['testarExpr',['../calculadora_8c.html#aeea81e19fb83c6c576385285bd18de2a',1,'calculadora.c']]],
  ['testcalcular',['testCalcular',['../teste__calculadora_8c.html#a5d7374ca81d5133c09daafe0a2fe4765',1,'teste_calculadora.c']]],
  ['testeditar',['testEditar',['../teste__calculadora_8c.html#a304cd1d1a6692c43b93628cadf951fed',1,'teste_calculadora.c']]],
  ['testinfixadaparaposfixada',['testInfixadaParaPosfixada',['../teste__calculadora_8c.html#a6b9f1e9a2b2f8df6ec4132bf1eb3d819',1,'teste_calculadora.c']]],
  ['testoperadoresseguidos',['testOperadoresSeguidos',['../teste__calculadora_8c.html#a669bdaef1d9dc2bd41b4a6c25cabc5c7',1,'teste_calculadora.c']]],
  ['testoperadorulimocaracter',['testOperadorUlimoCaracter',['../teste__calculadora_8c.html#a5dc1586127afd7c195275ef3f1f63808',1,'teste_calculadora.c']]],
  ['testparentetizacao1',['testParentetizacao1',['../teste__calculadora_8c.html#af488731f8646b8c000310f4aa788f864',1,'teste_calculadora.c']]],
  ['testparentetizacao2',['testParentetizacao2',['../teste__calculadora_8c.html#af5da2dd786084c109c8d92e281990232',1,'teste_calculadora.c']]],
  ['testparentetizacao3',['testParentetizacao3',['../teste__calculadora_8c.html#a8ca8e7b9410da9c40a2543cc369466bd',1,'teste_calculadora.c']]],
  ['testprioridade',['testPrioridade',['../teste__calculadora_8c.html#a28a8b581829b1e480ce6811b59e7163a',1,'teste_calculadora.c']]],
  ['testtestarexpressao',['testTestarExpressao',['../teste__calculadora_8c.html#a20c8c63953e408a85edf8593396ae4a0',1,'teste_calculadora.c']]],
  ['topopilha',['topoPilha',['../pilha_8c.html#a8ac38322e5f5836e1c60dad8a0a30840',1,'pilha.c']]]
];
