var searchData=
[
  ['calcular',['calcular',['../calculadora_8c.html#a7503dcaa719b6a341bea5d3b1fc271c2',1,'calculadora.c']]],
  ['clean_5fsuite',['clean_suite',['../teste__calculadora_8c.html#a1277ae7ecbaaad1479cfac38aaa7891d',1,'teste_calculadora.c']]],
  ['criarpilha',['criarPilha',['../pilha_8c.html#a5a53625b76864e7fe9463e4b4cd5f2ab',1,'pilha.c']]]
];
