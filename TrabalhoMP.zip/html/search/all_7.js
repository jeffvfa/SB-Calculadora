var searchData=
[
  ['removerpilha',['removerPilha',['../pilha_8c.html#a55e9ac1a9e8e157dcb50b046fbd0c56b',1,'pilha.c']]]
];
