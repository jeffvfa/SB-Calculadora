var searchData=
[
  ['editar',['editar',['../calculadora_8c.html#abc7a72c64e415e25b146a64531f1dbbf',1,'calculadora.c']]]
];
