var searchData=
[
  ['pilha_2ec',['pilha.c',['../pilha_8c.html',1,'']]],
  ['pilha_5flibera',['pilha_libera',['../pilha_8c.html#a0c5729ef6206cb9c33bc42f8f90e002e',1,'pilha.c']]],
  ['pilha_5fvazia',['pilha_vazia',['../pilha_8c.html#ae88130e22da20e845513e573cabea4a5',1,'pilha.c']]],
  ['prioridade',['Prioridade',['../calculadora_8c.html#a73d076157eb34cc02025effbf8ee2406',1,'calculadora.c']]]
];
