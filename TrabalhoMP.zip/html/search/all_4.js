var searchData=
[
  ['limpatela',['limpaTela',['../main_8c.html#a709439a2f16402fe60f9db86e06ec29a',1,'limpaTela():&#160;main.c'],['../teste__calculadora_8c.html#a709439a2f16402fe60f9db86e06ec29a',1,'limpaTela():&#160;teste_calculadora.c']]]
];
